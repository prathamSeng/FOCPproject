import random
import string

def encrypt_with_random_letters(message):
    interval = random.randint(2, 20)
    encrypted_message = ''
    
    for i, char in enumerate(message):
        encrypted_message += char
        if i < len(message) - 1:  
            random_letters = ''.join(random.choices(string.ascii_lowercase, k=interval))
            encrypted_message += random_letters

    return encrypted_message, interval

message = "send cheese"
encrypted_message, interval = encrypt_with_random_letters(message)
print(encrypted_message)  
print("Interval:", interval)


