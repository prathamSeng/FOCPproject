def to_binary(n):
    return bin(n)[2:]

print(to_binary(17))  