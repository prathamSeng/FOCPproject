def encrypt_message(message):
    return message.replace(" ", "")[::-1]

print(encrypt_message("pratham")) 