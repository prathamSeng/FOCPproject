sweets = int(input("Enter the total number of sweets: "))
pupils = int(input("Enter the number of pupils: "))

sweets_per_pupil = sweets // pupils
leftover_sweets = sweets % pupils

pupil_word = "pupils" if pupils > 1 else "pupil"
sweet_word = "sweets" if sweets_per_pupil > 1 else "sweet"
leftover_word = "sweets" if leftover_sweets > 1 else "sweet"

print(f"Each pupil will get {sweets_per_pupil} {sweet_word}, with {leftover_sweets} {leftover_word} left over.")
