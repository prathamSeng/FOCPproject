celsius = float(input("Enter a temperature in Celsius: "))
fahrenheit = (celsius * 1.8) + 32
print(f"{celsius}C is equivalent to {fahrenheit}F.")