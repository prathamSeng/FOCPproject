students = int(input("How many students? "))
group_size = int(input("Required group size? "))

groups = students // group_size
leftover = students % group_size

group_or_groups = "groups" if groups > 1 else "group"
student_or_students = "students" if leftover > 1 else "student"
print(f"There will be {groups} {group_or_groups} with {leftover} {student_or_students} left over.")
