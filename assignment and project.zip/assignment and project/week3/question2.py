new_password = input("Enter a new password: ")
confirm_password = input("Re-enter the password: ")
if new_password == confirm_password:
    print("Password Set")
else:
    print("Error: Passwords do not match.")