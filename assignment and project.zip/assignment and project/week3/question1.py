name = input("Enter your name: ")
name=name.strip()
if name == "":
    print("Hello, Stranger!")
else:
    print(f"Hello, {name}!")