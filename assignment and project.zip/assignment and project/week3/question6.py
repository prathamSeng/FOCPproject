for i in range(0,13):  
    print(f"{i} x 7 = {i * 7}")