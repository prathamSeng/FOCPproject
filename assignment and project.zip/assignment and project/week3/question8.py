number = int(input("Enter the number for the times table (positive or negative): "))

if number >= 0:
    for i in range(0,13):  
        print(f"{i} x {number} = {i * number}")
else:
    for i in range(12, -1, -1):  
        print(f"{i} x {abs(number)} = {i * abs(number)}")