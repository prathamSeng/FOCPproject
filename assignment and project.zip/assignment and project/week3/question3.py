new_password = input("Enter a new password (8-12 characters): ")
if 8 <= len(new_password) <= 12:
    confirm_password = input("Re-enter the password: ")
    if new_password == confirm_password:
        print("Password Set")
    else:
        print("Error: Passwords do not match.")
else:
    print("Error: Password must be between 8 and 12 characters long.")