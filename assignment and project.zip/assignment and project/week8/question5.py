import sys

def spell_command(filename):
    try:
        with open("/usr/share/dict/words", 'r') as dict_file:
            valid_words = set(word.strip().lower() for word in dict_file.readlines())
        
        with open(filename, 'r') as file:
            misspelled_words = set()
            
            for line in file:
                for word in line.split():
                    if word.strip('.,!?";:').lower() not in valid_words:
                        misspelled_words.add(word.strip('.,!?";:'))
            
            if misspelled_words:
                print("Misspelled words:")
                for word in misspelled_words:
                    print(word)
            else:
                print("No misspelled words found.")
    except FileNotFoundError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python spell_command.py <filename>")
    else:
        spell_command(sys.argv[1])
