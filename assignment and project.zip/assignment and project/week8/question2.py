import sys

def diff_command(file1, file2):
    try:
        with open(file1, 'r') as f1, open(file2, 'r') as f2:
            file1_lines = f1.readlines()
            file2_lines = f2.readlines()
            
            if file1_lines == file2_lines:
                print("The files are the same.")
            else:
                print("The files are different.")
    except FileNotFoundError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python diff_command.py <file1> <file2>")
    else:
        diff_command(sys.argv[1], sys.argv[2])
