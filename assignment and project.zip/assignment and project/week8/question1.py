import sys

def nl_command(file):
    try:
        with open(file, 'r') as file:
            for index, line in enumerate(file, start=1):
                print(f"{index} {line}", end='')  
    except FileNotFoundError:
        print(f"The file {file} was not found.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python nl_command.py <file>")
    else:
        nl_command(sys.argv[1])
