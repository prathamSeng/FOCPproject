def convert_temperature(temp):
    if temp[-1] == 'C':
        celsius = float(temp[:-1])
        fahrenheit = celsius_to_fahrenheit(celsius)
        return f"{fahrenheit}F"
    return "Invalid format"

print(convert_temperature("25C"))  