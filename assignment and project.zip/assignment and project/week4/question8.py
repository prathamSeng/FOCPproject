def temperatures():
    temps = []
    while True:
        temp = input("Enter a temperature (or press Enter to stop): ")
        if temp == "":
            break
        temps.append(float(temp))
    
    max_temp = max(temps) if temps else None
    min_temp = min(temps) if temps else None
    mean_temp = sum(temps) / len(temps) if temps else None
    
    return max_temp, min_temp, mean_temp

max_temp, min_temp, mean_temp = temperatures()
if max_temp is not None:
    print(f"Max: {max_temp}, Min: {min_temp}, Mean: {mean_temp}")
else:
    print("No temperatures entered.")