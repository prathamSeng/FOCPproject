def temperatures():
    temps = []
    for i in range(6):
        temp = float(input(f"Enter temperature {i+1}: "))
        temps.append(temp)
    
    max_temperature = max(temps)
    min_temperature = min(temps)
    mean_temperature = sum(temps) / len(temps)
    
    return max_temp, min_temp, mean_temp

max_temp, min_temp, mean_temp = temperatures()
print(f"Max: {max_temp}, Min: {min_temp}, Mean: {mean_temp}")