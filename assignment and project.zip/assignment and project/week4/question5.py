def celsius_to_fahrenheit(celsius):
    return (celsius * 1.8) + 32

def fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 0.55

print(celsius_to_fahrenheit(88))   
print(fahrenheit_to_celsius(9))  
