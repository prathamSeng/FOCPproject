def is_valid_number(num):
    return 0 <= num <= 100

print(is_valid_number(57))  
print(is_valid_number(160)) 