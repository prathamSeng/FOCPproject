def remove_last_character(string):
    if len(string) > 1:
        return string[:-1]
    return string

print(remove_last_character("TBCC"))  