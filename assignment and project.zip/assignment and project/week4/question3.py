def capitalize_name(name):
    return name.capitalize()

print(capitalize_name("pRathaM"))  