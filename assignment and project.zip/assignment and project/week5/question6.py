import sys
import shutil

if len(sys.argv) != 2:
    print("Please provide a file name.")
    sys.exit(1)

filename = sys.argv[1]

try:
    shutil.copy(filename, filename + ".bak")
    print(f"Backup of {filename} created as {filename}.bak")
except FileNotFoundError:
    print(f"Error: The file {filename} does not exist.")
