import sys
print(f"Number of arguments provided: {len(sys.argv) - 1}")
