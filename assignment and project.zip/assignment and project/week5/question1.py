import sys
print("Operating system platform:", sys.platform)
