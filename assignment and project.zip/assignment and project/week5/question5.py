import sys

if len(sys.argv) < 2:
    print("Please provide temperature readings.")
    sys.exit(1)

temperatures = [float(arg) for arg in sys.argv[1:]]

max_temp = max(temperatures)
min_temp = min(temperatures)
mean_temp = sum(temperatures) / len(temperatures)

print(f"Max Temperature: {max_temp}")
print(f"Min Temperature: {min_temp}")
print(f"Mean Temperature: {mean_temp}")
