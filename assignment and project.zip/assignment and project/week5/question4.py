import sys
import requests

if len(sys.argv) != 2:
    print("Please provide a URL.")
    sys.exit(1)

url = sys.argv[1]

try:
    response = requests.get(url)
    if response.status_code == 200:
        print(f"The website {url} is working!")
    else:
        print(f"The website {url} returned status code: {response.status_code}")
except requests.exceptions.RequestException as e:
    print(f"An error occurred: {e}")
