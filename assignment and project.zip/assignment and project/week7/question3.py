def manage_capitals():
    capitals = {}  
    while True:
        country = input("Enter the name of a country (or type 'exit' to quit): ").strip().lower()
        if country == 'exit':
            break
        if country in capitals:
            print(f"The capital of {country.capitalize()} is {capitals[country]}.")
        else:
            capital = input(f"Enter the capital of {country.capitalize()}: ").strip().capitalize()
            capitals[country] = capital
            print(f"Got it! The capital of {country.capitalize()} is now {capital}.")
manage_capitals()
