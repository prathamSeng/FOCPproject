def letters_in_at_least_one(word1, word2):
    return sorted(set(word1) | set(word2)) 

def letters_in_both(word1, word2):
    return sorted(set(word1) & set(word2))  

def letters_in_either_but_not_both(word1, word2):
    return sorted(set(word1) ^ set(word2))  

print(letters_in_at_least_one("cauliflower", "carrot"))  # Output: ['a', 'b', 'e', 'l', 'n', 'p']
print(letters_in_both("cauliflower", "carrot"))         # Output: ['a', 'n']
print(letters_in_either_but_not_both("cauliflower", "carrot"))  # Output: ['b', 'e', 'l', 'p']
