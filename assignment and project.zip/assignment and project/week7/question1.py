def unique_letters(string):
    unique_chars = set(string)
    return sorted(unique_chars)

print(unique_letters("cheese"))  
