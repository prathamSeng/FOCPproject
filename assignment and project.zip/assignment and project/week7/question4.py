from collections import Counter

def frequency_analysis(text):
    text = text.lower()
    freq = Counter(char for char in text if char.isalpha())  
    most_common = freq.most_common(6)
    
    for letter, count in most_common:
        print(f"{letter}: {count}")

frequency_analysis("British College")
