import random

assitant_names = ["Ronak", "Shivam", "Buddha", "Hanuman"]

responses = {
    "how are you": "I'm doing well, thank you!",
    "library": "The library is open 24/7 during exam periods.",
    "admission": "Admissions can be applied for through our online portal.",
    "scholarship": "Scholarship applications are accepted until the end of May."
}

random_responses = [
    "That's an interesting question! Anything else I can help with?",
    "I'm not sure about that. You might find more information on the university website."
]

def get_random_assitant_name():
    return random.choice(assitant_names)

def detect_keywords(user_input):
    for keyword, reply in responses.items():
        if keyword in user_input.lower():
            return reply
    return random.choice(random_responses)

def main_chat():
    
    user_name = input("Welcome! Please enter your name: ")
    print(f"Hello, {user_name}! Welcome to the University of Poppleton chat system.")
    
    assitant_name = get_random_assitant_name()
    print(f"My name is {assitant_name}, and I'm here to assist you today.")
    
    while True:
        user_input = input(f"{user_name}: ")
        
        if user_input.lower() in ["bye", "quit", "exit"]:
            print(f"{assitant_name}: Goodbye, {user_name}! Have a wonderful day!")
            break
        
        response = detect_keywords(user_input)
        print(f"{assitant_name}: {response}")

if __name__ == "__main__":
    main_chat()